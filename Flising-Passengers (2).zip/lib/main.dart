import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const FlisingApp());
}

class FlisingApp extends StatelessWidget {
  const FlisingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flising Passenger',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.orange,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Color(0xFF111111),
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white10),
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white10),
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.orange),
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
        ),
      ),
      home: const WelcomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: Column(
            children: [
              const Spacer(flex: 2),
              SizedBox(
                width: 130,
                height: 130,
                child: Image.asset(
                  'assets/images/flising_logo.png',
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(height: 40),
              const Text(
                'Welcome to Flising',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'We are one click away',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
              const Spacer(flex: 3),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const AuthScreen(),
                      ),
                    );
                  },
                  child: const Text(
                    'CONTINUE',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _signUp() {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isNotEmpty && password.isNotEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const RideScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter email and password')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            32,
            60,
            32,
            MediaQuery.of(context).viewInsets.bottom + 40,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Get Started',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Sign up or login to continue',
                style: TextStyle(color: Colors.grey, fontSize: 16),
              ),
              const SizedBox(height: 60),
              TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Email',
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _passwordController,
                obscureText: _obscurePassword,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Password',
                  hintStyle: const TextStyle(color: Colors.grey),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        _obscurePassword = !_obscurePassword;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 60),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                  ),
                  onPressed: _signUp,
                  child: const Text(
                    'SIGN UP',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: TextButton(
                  onPressed: _signUp,
                  child: const Text(
                    'Already have an account? Login',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Place {
  final String name;
  final LatLng latLng;
  const Place(this.name, this.latLng);
}

const List<Place> vanimoPlaces = [
  Place('Vanimo Airport (VAI)', LatLng(-2.6909, 141.3029)),
  Place('Vanimo Town Market', LatLng(-2.6885, 141.3035)),
  Place('Sandaun Provincial Hospital', LatLng(-2.6855, 141.3046)),
  Place('Vanimo Beach', LatLng(-2.6932, 141.3055)),
  Place('Sandaun Provincial Govt', LatLng(-2.6898, 141.3023)),
  Place('Vanimo Secondary School', LatLng(-2.6892, 141.2975)),
  Place('Holy Cross Catholic Church', LatLng(-2.6888, 141.2998)),
  Place('Vanimo Wharf / Port', LatLng(-2.6849, 141.3052)),
  Place('Lido Village & Beach', LatLng(-2.6720, 141.3180)),
  Place('Wutung Border Post', LatLng(-2.6420, 141.0070)),
];

class RideScreen extends StatefulWidget {
  const RideScreen({super.key});

  @override
  State<RideScreen> createState() => _RideScreenState();
}

class _RideScreenState extends State<RideScreen> {
  static const LatLng _vanimo = LatLng(-2.6830, 141.3020);

  final _pickupController = TextEditingController(text: 'Vanimo, PNG');
  final _dropoffController = TextEditingController();
  final _pickupFocus = FocusNode();
  final _dropoffFocus = FocusNode();
  bool _selectingPickup = true;

  final MapController _mapController = MapController();

  LatLng _mapCenter = _vanimo;
  LatLng? _currentLocation;

  LatLng? _pickupLatLng;
  LatLng? _dropoffLatLng;

  bool _isGettingLocation = false;
  bool _isRouting = false;

  final Distance _distance = const Distance();

  List<LatLng> _routePoints = [];
  double? _routeDistanceMeters;
  double? _routeDurationSeconds;

  @override
  void initState() {
    super.initState();
    _pickupLatLng = _vanimo;
  }

  @override
  void dispose() {
    _pickupController.dispose();
    _dropoffController.dispose();
    _pickupFocus.dispose();
    _dropoffFocus.dispose();
    super.dispose();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _useCurrentLocation() async {
    if (_isGettingLocation) return;

    setState(() {
      _isGettingLocation = true;
    });

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showMessage('Location services are disabled.');
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        _showMessage('Location permission denied.');
        return;
      }

      if (permission == LocationPermission.deniedForever) {
        _showMessage(
          'Location permission permanently denied. Enable it in settings.',
        );
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      final userLatLng = LatLng(position.latitude, position.longitude);

      if (!mounted) return;

      setState(() {
        _currentLocation = userLatLng;
        _mapCenter = userLatLng;
        _pickupLatLng = userLatLng;
        _pickupController.text =
            '${position.latitude.toStringAsFixed(5)}, ${position.longitude.toStringAsFixed(5)}';
        _selectingPickup = true;
        _pickupFocus.requestFocus();
      });

      _mapController.move(userLatLng, 15);
      _reverseGeocode(userLatLng, pickup: true);
      _updateRoute();
      _showMessage('Current location loaded.');
    } catch (e) {
      _showMessage('Failed to get location: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isGettingLocation = false;
        });
      }
    }
  }

  Future<void> _setFromMapCenter({required bool pickup}) async {
    final center = _mapController.camera.center;
    setState(() {
      if (pickup) {
        _pickupLatLng = center;
        _pickupController.text =
            '${center.latitude.toStringAsFixed(5)}, ${center.longitude.toStringAsFixed(5)}';
        _selectingPickup = true;
      } else {
        _dropoffLatLng = center;
        _dropoffController.text =
            '${center.latitude.toStringAsFixed(5)}, ${center.longitude.toStringAsFixed(5)}';
        _selectingPickup = false;
      }
    });
    _reverseGeocode(center, pickup: pickup);
    _updateRoute();
  }

  void _swapPickupDropoff() {
    setState(() {
      final tempLatLng = _pickupLatLng;
      _pickupLatLng = _dropoffLatLng;
      _dropoffLatLng = tempLatLng;

      final tempText = _pickupController.text;
      _pickupController.text = _dropoffController.text;
      _dropoffController.text = tempText;
    });
    _updateRoute();
  }

  Future<void> _fitToMarkers() async {
    if (_pickupLatLng == null && _dropoffLatLng == null) return;
    if (_pickupLatLng != null && _dropoffLatLng != null) {
      final bounds = LatLngBounds.fromPoints([_pickupLatLng!, _dropoffLatLng!]);
      try {
        _mapController.fitCamera(
          CameraFit.bounds(bounds: bounds, padding: const EdgeInsets.all(48)),
        );
      } catch (_) {
        final mid = LatLng(
          (_pickupLatLng!.latitude + _dropoffLatLng!.latitude) / 2,
          (_pickupLatLng!.longitude + _dropoffLatLng!.longitude) / 2,
        );
        _mapController.move(mid, 13);
      }
    } else {
      final target = _pickupLatLng ?? _dropoffLatLng!;
      _mapController.move(target, 15);
    }
  }

  double? get _straightDistanceMeters {
    if (_pickupLatLng == null || _dropoffLatLng == null) return null;
    return _distance.as(LengthUnit.Meter, _pickupLatLng!, _dropoffLatLng!);
  }

  double? get _fareKina {
    final m = _routeDistanceMeters ?? _straightDistanceMeters;
    if (m == null) return null;
    return m * 0.05;
  }

  void _requestRide() {
    final pickup = _pickupController.text.trim();
    final dropoff = _dropoffController.text.trim();

    if (pickup.isEmpty || dropoff.isEmpty) {
      _showMessage('Please enter pickup and destination');
      return;
    }

    final dist = _routeDistanceMeters ?? _straightDistanceMeters;
    final eta = _routeDurationSeconds;
    final parts = <String>[];
    if (dist != null) parts.add('${(dist / 1000).toStringAsFixed(2)} km');
    if (eta != null) parts.add('${(eta / 60).ceil()} min');
    if (_fareKina != null) parts.add('K${_fareKina!.toStringAsFixed(2)}');

    final suffix = parts.isNotEmpty ? ' • ${parts.join(' • ')}' : '';
    _showMessage('Requesting ride from $pickup to $dropoff$suffix');
  }

  Future<void> _updateRoute() async {
    if (_pickupLatLng == null || _dropoffLatLng == null) {
      setState(() {
        _routePoints = [];
        _routeDistanceMeters = null;
        _routeDurationSeconds = null;
      });
      return;
    }

    setState(() {
      _isRouting = true;
    });

    try {
      final p = _pickupLatLng!;
      final d = _dropoffLatLng!;
      final url = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/'
        '${p.longitude},${p.latitude};${d.longitude},${d.latitude}'
        '?overview=full&geometries=geojson',
      );

      final res = await http.get(
        url,
        headers: {
          'User-Agent': 'FlisingPassenger/1.0 (contact@example.com)',
        },
      );

      if (res.statusCode == 200) {
        final data = json.decode(res.body) as Map<String, dynamic>;
        final routes = data['routes'] as List<dynamic>?;
        if (routes != null && routes.isNotEmpty) {
          final r = routes.first as Map<String, dynamic>;
          final geom = r['geometry'] as Map<String, dynamic>;
          final coords = (geom['coordinates'] as List<dynamic>)
              .cast<List<dynamic>>()
              .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
              .toList();

          setState(() {
            _routePoints = coords;
            _routeDistanceMeters = (r['distance'] as num?)?.toDouble();
            _routeDurationSeconds = (r['duration'] as num?)?.toDouble();
          });
          return;
        }
      }

      setState(() {
        _routePoints = [_pickupLatLng!, _dropoffLatLng!];
        _routeDistanceMeters = _straightDistanceMeters;
        _routeDurationSeconds = _routeDistanceMeters != null
            ? (_routeDistanceMeters! / 1000) / 30.0 * 3600.0
            : null;
      });
    } catch (_) {
      setState(() {
        _routePoints = [_pickupLatLng!, _dropoffLatLng!];
        _routeDistanceMeters = _straightDistanceMeters;
        _routeDurationSeconds = _routeDistanceMeters != null
            ? (_routeDistanceMeters! / 1000) / 30.0 * 3600.0
            : null;
      });
    } finally {
      if (mounted) {
        setState(() {
          _isRouting = false;
        });
      }
    }
  }

  Future<void> _reverseGeocode(LatLng p, {required bool pickup}) async {
    try {
      final url = Uri.parse(
        'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${p.latitude}&lon=${p.longitude}&zoom=16',
      );
      final res = await http.get(
        url,
        headers: {
          'User-Agent': 'FlisingPassenger/1.0 (contact@example.com)',
        },
      );
      if (res.statusCode == 200) {
        final data = json.decode(res.body) as Map<String, dynamic>;
        final name = (data['name'] ?? data['display_name'] ?? '').toString();
        if (name.isNotEmpty && mounted) {
          setState(() {
            final text = '$name (${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)})';
            if (pickup) {
              _pickupController.text = text;
            } else {
              _dropoffController.text = text;
            }
          });
        }
      }
    } catch (_) {}
  }

  Widget _placeAutocompleteField({
    required bool isPickup,
    required String hint,
  }) {
    final controller = isPickup ? _pickupController : _dropoffController;
    final focus = isPickup ? _pickupFocus : _dropoffFocus;

    return RawAutocomplete<Place>(
      textEditingController: controller,
      focusNode: focus,
      optionsBuilder: (TextEditingValue value) {
        final q = value.text.trim().toLowerCase();
        if (q.isEmpty) return vanimoPlaces;
        return vanimoPlaces.where((p) => p.name.toLowerCase().contains(q));
      },
      displayStringForOption: (Place p) => p.name,
      onSelected: (Place p) {
        setState(() {
          if (isPickup) {
            _pickupController.text = p.name;
            _pickupLatLng = p.latLng;
            _selectingPickup = true;
          } else {
            _dropoffController.text = p.name;
            _dropoffLatLng = p.latLng;
            _selectingPickup = false;
          }
        });
        _mapController.move(p.latLng, 15);
        _updateRoute();
      },
      fieldViewBuilder: (context, textController, focusNode, onSubmitted) {
        return TextField(
          controller: textController,
          focusNode: focusNode,
          onTap: () => setState(() => _selectingPickup = isPickup),
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Colors.grey),
            prefixIcon: Icon(
              isPickup ? Icons.my_location : Icons.location_on,
              color: isPickup ? Colors.blue : Colors.red,
              size: 20,
            ),
            suffixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isPickup)
                  _isGettingLocation
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.orange,
                            ),
                          ),
                        )
                      : IconButton(
                          tooltip: 'Use current location',
                          icon: const Icon(Icons.gps_fixed, color: Colors.grey, size: 20),
                          onPressed: _useCurrentLocation,
                        ),
                IconButton(
                  tooltip: 'Clear',
                  icon: const Icon(Icons.clear, color: Colors.grey, size: 20),
                  onPressed: () {
                    setState(() {
                      controller.clear();
                      if (isPickup) {
                        _pickupLatLng = null;
                        _selectingPickup = true;
                      } else {
                        _dropoffLatLng = null;
                        _selectingPickup = false;
                      }
                      _updateRoute();
                    });
                  },
                ),
              ],
            ),
          ),
        );
      },
      optionsViewBuilder: (context, onSelected, options) {
        final opts = options.toList();
        return Align(
          alignment: Alignment.topLeft,
          child: Material(
            color: Colors.black.withOpacity(0.96),
            elevation: 8,
            borderRadius: BorderRadius.circular(12),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 240, minWidth: 300),
              child: ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: opts.length,
                itemBuilder: (context, index) {
                  final place = opts[index];
                  return ListTile(
                    dense: true,
                    leading: Icon(
                      isPickup ? Icons.place_outlined : Icons.flag_outlined,
                      color: isPickup ? Colors.orange : Colors.red,
                      size: 20,
                    ),
                    title: Text(place.name, style: const TextStyle(color: Colors.white)),
                    subtitle: Text(
                      '${place.latLng.latitude.toStringAsFixed(4)}, ${place.latLng.longitude.toStringAsFixed(4)}',
                      style: const TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                    onTap: () => onSelected(place),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final polylinePoints = _routePoints.isNotEmpty
        ? _routePoints
        : <LatLng>[
            if (_pickupLatLng != null) _pickupLatLng!,
            if (_dropoffLatLng != null) _dropoffLatLng!,
          ];

    final distanceToShow = _routeDistanceMeters ?? _straightDistanceMeters;
    final etaToShowSec = _routeDurationSeconds;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Image.asset(
                'assets/images/flising_logo.png',
                height: 28,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Flising Passenger',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const Spacer(),
            if (_isRouting)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.orange),
              ),
            const SizedBox(width: 12),
          ],
        ),
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _mapCenter,
              initialZoom: 14.0,
              onLongPress: (tapPos, latLng) {
                setState(() {
                  if (_selectingPickup) {
                    _pickupLatLng = latLng;
                    _pickupController.text =
                        '${latLng.latitude.toStringAsFixed(5)}, ${latLng.longitude.toStringAsFixed(5)}';
                  } else {
                    _dropoffLatLng = latLng;
                    _dropoffController.text =
                        '${latLng.latitude.toStringAsFixed(5)}, ${latLng.longitude.toStringAsFixed(5)}';
                  }
                });
                _reverseGeocode(latLng, pickup: _selectingPickup);
                _updateRoute();
                _showMessage(
                    'Pinned ${_selectingPickup ? 'Pickup' : 'Dropoff'} at ${latLng.latitude.toStringAsFixed(5)}, ${latLng.longitude.toStringAsFixed(5)}');
              },
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.flising',
              ),
              if (polylinePoints.length >= 2)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: polylinePoints,
                      color: Colors.orange,
                      strokeWidth: 4,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  if (_pickupLatLng != null)
                    Marker(
                      point: _pickupLatLng!,
                      width: 50,
                      height: 50,
                      child: const Icon(
                        Icons.location_pin,
                        color: Colors.greenAccent,
                        size: 40,
                      ),
                    ),
                  if (_dropoffLatLng != null)
                    Marker(
                      point: _dropoffLatLng!,
                      width: 50,
                      height: 50,
                      child: const Icon(
                        Icons.location_pin,
                        color: Colors.redAccent,
                        size: 40,
                      ),
                    ),
                  if (_currentLocation != null)
                    Marker(
                      point: _currentLocation!,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.my_location,
                        color: Colors.lightBlueAccent,
                        size: 26,
                      ),
                    ),
                ],
              ),
            ],
          ),
          IgnorePointer(
            child: Center(
              child: Icon(
                Icons.add_location_alt_outlined,
                color: Colors.white70,
                size: 28,
              ),
            ),
          ),
          Positioned(
            right: 16,
            bottom: 200,
            child: FloatingActionButton(
              backgroundColor: Colors.black87,
              foregroundColor: Colors.white,
              heroTag: 'fit',
              onPressed: _fitToMarkers,
              child: const Icon(Icons.center_focus_strong),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        color: Colors.black,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white10),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _placeAutocompleteField(
                            isPickup: true,
                            hint: 'Pickup location (Vanimo)',
                          ),
                        ),
                        const SizedBox(width: 8),
                        IconButton(
                          tooltip: 'Swap',
                          onPressed: _swapPickupDropoff,
                          icon: const Icon(Icons.swap_vert, color: Colors.orange),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _placeAutocompleteField(
                      isPickup: false,
                      hint: 'Where to? (Vanimo)',
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white70,
                              side: const BorderSide(color: Colors.white24),
                            ),
                            onPressed: () => _setFromMapCenter(pickup: true),
                            icon: const Icon(Icons.add_location_alt_outlined, size: 18),
                            label: const Text('Set pickup = map center'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white70,
                              side: const BorderSide(color: Colors.white24),
                            ),
                            onPressed: () => _setFromMapCenter(pickup: false),
                            icon: const Icon(Icons.flag_outlined, size: 18),
                            label: const Text('Set dropoff = map center'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            distanceToShow != null
                                ? 'Distance: ${((distanceToShow) / 1000).toStringAsFixed(2)} km'
                                : 'Distance: —',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        ),
                        if (etaToShowSec != null)
                          Text(
                            'ETA: ${(etaToShowSec / 60).ceil()} min',
                            style: const TextStyle(color: Colors.white70),
                          ),
                        const SizedBox(width: 12),
                        Text(
                          _fareKina != null
                              ? 'Fare: K${_fareKina!.toStringAsFixed(2)}'
                              : 'Fare: —',
                          style: const TextStyle(
                            color: Colors.orange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Tip: Long-press the map to pin the focused field.',
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                    ),
                  ),
                  onPressed: _requestRide,
                  child: Text(
                    _fareKina != null
                        ? 'BOOK A RIDE • K${_fareKina!.toStringAsFixed(2)}'
                        : 'BOOK A RIDE',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}